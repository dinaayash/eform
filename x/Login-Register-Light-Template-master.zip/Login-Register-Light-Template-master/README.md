<h1>Login Register Template | Light Version</h1>
Pure CSS and HTML template using Materialize's icons<br>
This is the light version you can see the dark version <a href="https://github.com/MrLolok/Login-Register-Template/">here</a>
<br>
<br>
Website Preview:
<br><br><br>
Login:
<img src="https://image.prntscr.com/image/QGgCNE4bTo2dZIqL_rm6rg.png" title="Login page" />
<br><br>
Register:
<img src="https://image.prntscr.com/image/V5r1QjTmSfq28uoW3bdp1A.png" title="Register page" />
